﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            int numero1, numero2;

            if (!int.TryParse(txtNum1.Text, out numero1) || (numero1 <= 0))
            {
                MessageBox.Show("Número 1 inválido!");
                txtNum1.Focus();
            }

            if (!int.TryParse(txtNum2.Text, out numero2) || (numero2 <= 0))
            {
                MessageBox.Show("Número 2 inválido!");
                txtNum2.Focus();
            }

            else if (numero1 > numero2)
            {
                MessageBox.Show("Número 1 maior que Número 2!");
                txtNum1.Focus();
            }
            else
            {
                Random ObjR = new Random();
                int sorteado = ObjR.Next(numero1, numero2);
                MessageBox.Show($"O número sorteado foi: {sorteado}");
            }

        }
    }
}
