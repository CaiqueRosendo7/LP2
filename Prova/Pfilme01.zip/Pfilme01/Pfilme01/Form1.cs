﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pfilme01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] avaliacoes = new double[3, 2];
            string aux = "";
            double[] notaPorFilme = new double[2];
            double[] mediaFilme = new double[2];

            for (int i = 0; i < avaliacoes.GetLength(0); i++)
            {
                for (int j = 0; j < avaliacoes.GetLength(1); j++)
                {
                    aux = Interaction.InputBox($"Insira a nota da pessoa {i + 1} para o Filme {j + 1}", "Entrada de dados");
                    if (aux == "")
                    {
                        return;
                    }
                    if (!double.TryParse(aux, out avaliacoes[i, j]) || avaliacoes[i, j] < 0 || avaliacoes[i, j] > 10)
                    {
                        MessageBox.Show("Insira um valor válido!");
                        j--;
                    }
                    else
                    {
                        notaPorFilme[j] += avaliacoes[i, j];                   
                    }

                    mediaFilme[j] = notaPorFilme[j] / avaliacoes.GetLength(1);

                }
            }

            for (int i = 0; i < 3; i++)
            {
                lstbxFilmes.Items.Add($"Pessoa: {i+ 1} Nota do Filme 1: {notaPorFilme[i]:F2} Nota do Filme 2: {notaPorFilme[i+1]:F2}");
            }
            for (int i = 0; i<2; i++)
            {
                lstbxFilmes.Items.Add($"Media filme {i + 1}: {mediaFilme[i]}");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxFilmes.Items.Clear();
        }
    }
}
