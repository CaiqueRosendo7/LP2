﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
        
    {
        double ladoA, ladoB, ladoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }
            if (!double.TryParse(txtLadoA.Text, out double ladoA))
            {
                MessageBox.Show("Digite um valor válido para Lado A!");
            }
        }

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }
            if (!double.TryParse(txtLadoB.Text, out double ladoB))
            {
                MessageBox.Show("Digite um valor válido para Lado B!");
            }
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }
            if (!double.TryParse(txtLadoC.Text, out double ladoC))
            {
                MessageBox.Show("Digite um valor válido para Lado C!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
            ladoA = 0;
            ladoB = 0;
            ladoC = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ladoA = double.Parse(txtLadoA.Text);
            ladoB = double.Parse(txtLadoB.Text);
            ladoC = double.Parse(txtLadoC.Text);

            if ((ladoA < (ladoB + ladoC)) && (ladoA > (Math.Abs(ladoB - ladoC))) &&
                (ladoB < (ladoA + ladoC)) && (ladoB > (Math.Abs(ladoA - ladoC))) &&
                (ladoC < (ladoA + ladoB)) && (ladoC > (Math.Abs(ladoA - ladoB))))
            {
                if (ladoA == ladoB && ladoB == ladoC)
                {
                    MessageBox.Show("Triângulo Equilátero!");
                }
                else if (ladoA == ladoB || ladoA == ladoC || ladoB == ladoC)
                {
                    MessageBox.Show("Triângulo Isósceles!");
                }
                else 
                {
                    MessageBox.Show("Triângulo Escaleno!");
                }

            }
            else
            {
                MessageBox.Show("Não é um triângulo!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
