﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux = "";

            for (int i = 0; i < vetor.Length; i++)
            {
                aux = Interaction.InputBox($"Digite número {i + 1}", "Entrada de dados");

                if (!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Valor inválido!");
                    i--;
                }
            }

            Array.Reverse(vetor);
            aux = "";

            foreach (int x in vetor)
                aux += x + "\n";

            MessageBox.Show(aux);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            string nomes = "";

            ArrayList alunos = new ArrayList();
            alunos.Add("Ana");
            alunos.Add("André");
            alunos.Add("Beatriz");
            alunos.Add("Camila");
            alunos.Add("João");
            alunos.Add("Joana");
            alunos.Add("Otávio");
            alunos.Add("Marcelo");
            alunos.Add("Pedro");
            alunos.Add("Thais");

            alunos.Remove("Otávio");

            foreach (string nome in alunos)
            {
                nomes += nome + "\n";
            }

            MessageBox.Show($"Os nomes são: \n{nomes}");
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string aux = "";

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    aux = Interaction.InputBox($"Didite a nota {j + 1} do aluno {i + 1}");

                    if (!double.TryParse(aux, out notas[i, j]) || notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("Valor inválido! Insira um número de 0 a 10!");
                        j--;
                    }
                }

            }
            for (int i = 0; i < notas.GetLength(0); i++)
            {
                double media = 0;
                for (int j = 0; j < notas.GetLength(1); j++)
                {
                    media += notas[i, j];
                }
                media /= 3;
                MessageBox.Show($"A média do aluno {i + 1} é: {media:F2}");
            }
        }

        private void btnExercício4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio4>().Count() > 0)
            {
                MessageBox.Show("Form já existente!");
                Application.OpenForms["FrmExercicio4"].BringToFront();
            }
            else
            {
                FrmExercicio4 FrmExercicio4 = new FrmExercicio4();
                FrmExercicio4.Show();
            }
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio5>().Count() > 0)
            {
                MessageBox.Show("Form já existente!");
                Application.OpenForms["FrmExercicio5"].BringToFront();
            }
            else
            {
                FrmExercicio5 FrmExercicio5 = new FrmExercicio5();
                FrmExercicio5.Show();
            }
        }
    }
}
