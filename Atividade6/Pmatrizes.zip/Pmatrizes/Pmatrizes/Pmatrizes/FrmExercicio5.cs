﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class FrmExercicio5 : Form
    {
        public FrmExercicio5()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            char[,] questoes = new char[2, 10];
            char[] gabarito = new char[10] {'C', 'B', 'A', 'A', 'D', 'D', 'E', 'B', 'C', 'E'};

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    string resposta = Interaction.InputBox($"Insira a resposta da questão {j + 1} do aluno {i + 1}: ", "Registro de respostas").ToUpper();
                    if (!char.TryParse(resposta, out questoes[i, j]) || questoes[i, j] < 'A' || questoes[i, j] > 'E')
                    {
                        MessageBox.Show("Resposta inválida!");
                        j--;
                    }
                }

            }
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    if (questoes[i, j] == gabarito[j])
                    {
                        lstbxGabarito.Items.Add($"Aluno {i + 1} - Questão {j + 1} acertou. Resposta: {questoes[i, j]}");
                    }
                    else
                    {
                        lstbxGabarito.Items.Add($"Aluno {i + 1} - Questão {j + 1} errou. Escolheu: {questoes[i, j]}. Era: {gabarito[j]}");
                    }
                }
            }
        }
    }
}
