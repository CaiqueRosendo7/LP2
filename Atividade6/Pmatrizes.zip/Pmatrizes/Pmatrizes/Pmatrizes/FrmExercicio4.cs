﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            int[] qtdCaracteres = new int[10];

            for (int i = 0; i < 10; i++)
            {
                nomes[i] = Interaction.InputBox("Insira um nome", "Entrada de nomes");
                foreach (char c in nomes[i])
                {
                    qtdCaracteres[i]++;
                    if (char.IsWhiteSpace(c))
                    {
                        MessageBox.Show("Nome inválido");
                        qtdCaracteres[i]--;
                    }
                }
            }

            for (int i = 0; i < 10; i++)
            {
                lstbxNomes.Items.Add($"O nome:{nomes[i]} tem {qtdCaracteres[i]} caracteres");
            }
        }
    }
}
