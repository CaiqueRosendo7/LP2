﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double num1;
        double num2;
        double resultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            resultado = num1 + num2;
            txtResultado.Text = resultado.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            resultado = num1 / num2;
            txtResultado.Text = resultado.ToString();
        }

        private void txtNumero1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl==btnSair)
            {
                return;
            }
            if (!Double.TryParse(txtNumero1.Text, out num1))
            {
                MessageBox.Show("Número inválido!");
                txtNumero1.Focus();
            }
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }
            if (!Double.TryParse(txtNumero2.Text, out num2))
            {
                MessageBox.Show("Número inválido!");
                txtNumero2.Focus();
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear(); 
            txtNumero2.Clear();
            txtResultado.Clear();
            num1 = 0;   
            num2 = 0;
            resultado = 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
         
        }

        private void btnSubtrair_Click(object sender, EventArgs e)
        {
            resultado = num1 - num2;
            txtResultado.Text = resultado.ToString();
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            resultado = num2 * num1;
            txtResultado.Text = resultado.ToString();
        }
    }
}
