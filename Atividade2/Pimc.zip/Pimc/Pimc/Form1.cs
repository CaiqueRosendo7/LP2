﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double altura, peso, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {
                    }

        private void lblAltura_Click(object sender, EventArgs e)
        {

        }

        private void mskTxtAltura_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            resultado = peso / (altura * altura);
            resultado = Math.Round(resultado, 1);
            txtIMC.Text = resultado.ToString();

            if (resultado < 18.5)
            {
                MessageBox.Show("Magreza");
            }
            else if (resultado <= 24.9)
            {
                MessageBox.Show("Normal");
            }
            else if (resultado <= 29.9)
            {
                MessageBox.Show("Sobrepeso");
            }
            else if (resultado <= 39.9)
            {
                MessageBox.Show("Obesidade");
            }
            else
            {
                MessageBox.Show("Obesidade severa");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPeso.Clear();
            txtIMC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void mskTxtAltura_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }

            if (!double.TryParse(mskbxAltura.Text, out altura) ||
                (altura <= 0))
            {
                MessageBox.Show("Altura inválida");
                mskbxAltura.Focus();
            }
        }

        private void mskTxtPeso_Validated(object sender, EventArgs e)
        {
            if (this  .ActiveControl == btnSair)
            {
                return;
            }

            if (!double.TryParse(mskbxPeso.Text, out peso)||
                (peso <=0 ))
            {
                MessageBox.Show("Peso inválido");
                mskbxPeso.Focus();
            }
        }
    }
}
