﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade5
{
    public partial class frmExercicio2 : Form
    {
        int n = 1;
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnTestar_Click(object sender, EventArgs e)
        {
            double h = 0;

            for(int i = 1; i <= n; i++)
            {
                h += 1.0 / i;
            }

            MessageBox.Show($"O número H de {n} é: {h:f2}");
        }

        private void txtNumeroN_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNumeroN.Text, out n) || n <= 0)
            {
                MessageBox.Show("Insira um número inteiro positivo maior que zero!");
                txtNumeroN.Focus();
                return;
            }
        }
    }
}
