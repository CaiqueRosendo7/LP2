﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade5
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnSalarioBruto_Click(object sender, EventArgs e)
        {
            string nome;
            int producao;
            double salario, gratificacao, salarioBruto;
            int B = 0, C = 0, D = 0;

            nome = txtNome.Text;
            producao = Convert.ToInt32(txtProducao.Text);
            salario = Convert.ToDouble(txtSalario.Text);
            gratificacao = Convert.ToDouble(txtGratificacao.Text);

            if (producao >= 100)
            {
                B = 1;
            }

            if (producao >= 120)
            {
                C = 1;
            }

            if (producao >= 150)
            {
                D = 1;
            }
            salarioBruto = salario + salario * (0.05 * B + 0.1 * C + 0.1 * D) + gratificacao;

            if (salarioBruto > 7000)
            {
                if (producao >= 150 && gratificacao > 0)
                {
                    MessageBox.Show("Funcionário: " + nome + "\nSalário Bruto: R$ " + salarioBruto.ToString("F2"));
                }
                else
                {
                    salarioBruto = 7000;
                    MessageBox.Show("Funcionário: " + nome + "\nSalário Bruto: R$ " + salarioBruto.ToString("F2"));
                }
            }
            else
            {
                MessageBox.Show("Funcionário: " + nome + "\nSalário Bruto: R$ " + salarioBruto.ToString("F2"));
            }

        }

        private void txtMatricula_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtMatricula.Text, out int matricula) || matricula <= 0)
            {
                MessageBox.Show("Digite um número de matrícula válido!");
                txtMatricula.Focus();
                return;
            }
        }

        private void txtProducao_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtProducao.Text, out int producao) || producao < 0)
            {
                MessageBox.Show("Digite um número válido!");
                txtProducao.Focus();
                return;
            }
        }

        private void txtSalario_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtSalario.Text, out double salario) || salario <= 0)
            {
                MessageBox.Show("Digite um salário válido!");
                txtSalario.Focus();
                return;
            }
        }

        private void txtGratificacao_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtGratificacao.Text, out double gratificacao) || gratificacao < 0)
            {
                MessageBox.Show("Digite um valor válido!");
                txtGratificacao.Focus();
                return;
            }
        }
    }
}
