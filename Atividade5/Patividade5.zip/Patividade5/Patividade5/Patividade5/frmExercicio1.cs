﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade5
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspaço_Click(object sender, EventArgs e)
        {
            int qtdEspaco = 0;
            foreach(char letra in rchtxtFrase.Text)
            {
                if (letra == ' ')
                {
                    qtdEspaco++;
                }
            }
            MessageBox.Show($"Quantidade de espaços em branco: {qtdEspaco}");
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            int i = 0, qtdR = 0;
            while (i < rchtxtFrase.TextLength)
            {
                if (rchtxtFrase.Text[i] == 'R' || rchtxtFrase.Text[i] == 'r')
                {
                    qtdR++;
                }
                i++;
            }
            MessageBox.Show($"Quantidade de letras R: {qtdR}");

        }

        private void btnLetras_Click(object sender, EventArgs e)
        {
            int qtdPares = 0;

            for (int i = 0; i < rchtxtFrase.TextLength - 1; i++)
            {
                if (rchtxtFrase.Text[i] == rchtxtFrase.Text[i + 1])
                {
                    qtdPares++;
                }
            }
            MessageBox.Show($"Quantidade de pares de letra: {qtdPares}");
        }
    }
}
