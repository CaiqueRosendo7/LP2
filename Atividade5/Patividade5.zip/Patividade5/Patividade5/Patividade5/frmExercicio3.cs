﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade5
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnPalindromo_Click(object sender, EventArgs e)
        {
            string aux = "";
            string frase = txtFrase.Text.Replace(" ","").ToLower();

            for (int i = txtFrase.Text.Length - 1; i >= 0; i--)
            {
                aux += txtFrase.Text[i];
            }
            aux = aux.Replace(" ", "").ToLower();

            if (frase == aux)
            {
                MessageBox.Show("É um palíndromo!");
            }
            else
            {
                MessageBox.Show("Não é um palíndromo!");
            }
            
        }
    }
}
