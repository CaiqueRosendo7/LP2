﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PatividadeExtra
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double[,] compras = new double[7, 5];
            string[] diaSemana = new string[7] { "Domingo", "Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado" };
            double[] totalPorDia = new double[7];
            double totalGeral = 0;
            string aux = "";

            for(int i = 0; i < compras.GetLength(0); i++)
            {
                for(int j = 0; j < compras.GetLength(1); j++)
                {
                    aux = Interaction.InputBox($"Insira o valor do produto {j + 1} de {diaSemana[i]}:","Entrada de dados");
                    if(aux == "")
                    {
                        return;
                    }
                    if (!double.TryParse(aux, out compras[i, j]) || compras[i, j] < 0)
                    {
                        MessageBox.Show("Insira um valor válido!");
                        j--;
                    }
                    else
                    {
                        totalPorDia[i] += compras[i, j];
                    }
                }

                totalGeral += totalPorDia[i];
            }
            for (int i = 0;i < compras.GetLength(0);i++)
            {
                lstbxTotalGeral.Items.Add($"Total de {diaSemana[i]}: R$ {totalPorDia[i]:F2}");
            }
            lstbxTotalGeral.Items.Add("");
            lstbxTotalGeral.Items.Add($"Total geral: R$ {totalGeral:F2}");
        }
    }
}
