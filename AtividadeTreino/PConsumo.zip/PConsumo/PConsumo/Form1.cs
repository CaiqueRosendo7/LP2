﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PConsumo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] consumo = new double[5, 4];
            string aux = "";
            string[] setor = new string[5] { "Produção","Escritório","Refeitório","Limpeza","Logística"};
            double [] totalSetor = new double [5];
            double[] valSetor = new double[5];
            double totalGeral = 0;
            for (int i = 0; i < consumo.GetLength(0); i++)
            {
                for (int j = 0; j < consumo.GetLength(1); j++)
                {
                    aux = Interaction.InputBox($"Insira o valor do consumo da semana {j+1} no setor de {setor[i]}: ", "Entrada de valores");
                    if (aux == "")
                    {
                        return;
                    }
                    if (!double.TryParse(aux, out consumo[i, j]) || consumo[i, j] < 0)
                    {
                        MessageBox.Show("Insira um valor válido!");
                        j--;
                    }
                    else
                    {
                        totalSetor[i] += consumo[i, j];
                    }
                }
                valSetor[i] += totalSetor[i] * 0.01;
                totalGeral += valSetor[i];
            }
            for (int i = 0; i < consumo.GetLength(0); i++)
            {
                lstbxRelatorioConsumo.Items.Add($"{setor[i]}: {totalSetor[i]}L  -> {valSetor[i]:C2}");
            }
            lstbxRelatorioConsumo.Items.Add("");
            lstbxRelatorioConsumo.Items.Add($"Total geral: R$ {totalGeral:C2}");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxRelatorioConsumo.Items.Clear();
        }
    }
}
